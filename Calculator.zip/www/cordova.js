/*!
 * This file is part of App Builder
 * For licenses information see App Builder help
 * ©2017 App Builder - https://www.davidesperalta.com
 */
window.App.Cordova = true;
